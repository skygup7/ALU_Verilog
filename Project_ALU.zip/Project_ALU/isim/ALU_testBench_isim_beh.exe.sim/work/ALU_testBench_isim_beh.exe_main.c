/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000002737428971_1497867041_init();
    work_m_00000000000012284406_0833183191_init();
    work_m_00000000001911342940_4206758324_init();
    work_m_00000000001911342940_0075896155_init();
    work_m_00000000002002155427_1128913257_init();
    work_m_00000000001719768091_1345475044_init();
    work_m_00000000003517638111_0432546625_init();
    work_m_00000000001759534510_1256520921_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001759534510_1256520921");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
